from kivy.uix.bubble import Bubble
from math import fabs


class Keypad(Bubble):
    def __init__(self, widget):
        super(Keypad, self).__init__()
        self.widget = widget
        self.num = ''
        self.x = widget.x - fabs(self.width - widget.width)
        self.y = widget.y - self.height
